#pragma once
#include "IDocumentPart.h"
#include <iostream>

using namespace std;

class Paragraph : IDocumentPart
{
public:
	void print()
	{
		cout << "print Paragraph";
	}
};