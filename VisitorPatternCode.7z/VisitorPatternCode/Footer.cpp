#pragma once
#include "IDocumentConverter.h"
#include "IDocumentPart.h"
#include <iostream>

using namespace std;
class Footer : public IDocumentPart
{
public:
	void paint()
	{
		cout << "Paint Footer"<<endl;
	}
	void convert(IDocumentConverter* pConverter)
	{
		pConverter->convertFooter(this);
	}
};