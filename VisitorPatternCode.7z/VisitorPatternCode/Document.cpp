#include "pch.h"
#include "Document.h"
#include "IDocumentConverter.h"
#include "IDocumentPart.h"
#include <iostream>

using namespace std;
Document::Document()
{
}


Document::~Document()
{
}

void Document::Add(IDocumentPart* ptr)
{
	m_docPartList.push_back(ptr);
}

void Document::open()
{
	for (IDocumentPart* var : m_docPartList)
	{
		(*var).paint();
	}
}

void Document::close()
{
}

void Document::save()
{
}


void Document::convert(IDocumentConverter* pDocConverter)
{
	for (IDocumentPart* var : m_docPartList)
	{
		(*var).convert(pDocConverter);
	}

}