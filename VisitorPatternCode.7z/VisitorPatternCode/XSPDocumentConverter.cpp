#pragma once
#include "IDocumentConverter.h"
#include <iostream>

using namespace std;
class XSPDocumentConverter :public IDocumentConverter
{
public:
	void convertHeader(IDocumentPart* pDocPart)
	{
		cout << "Converted Header part to XSP document" << endl;
	}

	void convertFooter(IDocumentPart* pDocPart)
	{
		cout << "Converted Footer part to XSP document" << endl;
	}

	void convertHyperLink(IDocumentPart* pDocPart)
	{
		cout << "Converted HyperLink part to XSP document" << endl;
	}
};