#pragma once
#include "IDocumentConverter.h"
#include "IDocumentPart.h"
#include <list>
#include <iterator>

using namespace std;
class Document
{
	list<IDocumentPart*> m_docPartList;
	IDocumentPart* m_docPartPtr;
	IDocumentConverter* m_docConverter;
	
public:
	Document();
	~Document();
	void Add(IDocumentPart *);
	void open();
	void close();
	void save();
	void convert(IDocumentConverter*);
};

