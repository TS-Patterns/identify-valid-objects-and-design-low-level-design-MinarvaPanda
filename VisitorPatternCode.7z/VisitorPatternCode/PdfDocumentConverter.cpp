#pragma once
#include "IDocumentConverter.h"
#include <iostream>

using namespace std;
class PdfDocumentConverter : public IDocumentConverter
{
public:
	void convertHeader(IDocumentPart* pDocPart)
	{
		cout << "Converted Header part to PDF document" << endl;
	}

	void convertFooter(IDocumentPart* pDocPart)
	{
		cout << "Converted Footer part to PDF document" << endl;
	}

	void convertHyperLink(IDocumentPart* pDocPart)
	{
		cout << "Converted HyperLink part to PDF document" << endl;
	}
};