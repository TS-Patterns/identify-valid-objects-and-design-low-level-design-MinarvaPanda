#pragma once
#include "IDocumentConverter.h"
#include "IDocumentPart.h"
#include <iostream>

using namespace std;
class HyperLink : public IDocumentPart
{
public:
	void paint()
	{
		cout << "paint HyperLink"<<endl;
	}
	void convert(IDocumentConverter* pConverter)
	{
		pConverter->convertHyperLink(this);
	}
};