#pragma once
#include "IDocumentConverter.h"

class IDocumentConverter;
class IDocumentPart 
{
	public:
		 virtual void paint() = 0 ;
		 virtual void convert(IDocumentConverter* converter) = 0;
};


