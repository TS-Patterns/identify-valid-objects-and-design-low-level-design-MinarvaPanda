#pragma once
#include "IDocumentPart.h"

class IDocumentPart;

class IDocumentConverter
{
public:
	virtual void convertHeader(IDocumentPart*) = 0;
	virtual void convertFooter(IDocumentPart*) = 0;
	virtual void convertHyperLink(IDocumentPart*) = 0;	
};
