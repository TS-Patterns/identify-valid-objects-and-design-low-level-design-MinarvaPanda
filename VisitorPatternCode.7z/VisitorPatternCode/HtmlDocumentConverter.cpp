#pragma once
#include "IDocumentConverter.h"
#include <iostream>

using namespace std;
class HtmlDocumentConverter : public IDocumentConverter
{
public:
	void convertHeader(IDocumentPart* pDocPart)
	{
		cout << "Converted Header part to HTML document" << endl;
	}

	void convertFooter(IDocumentPart* pDocPart)
	{
		cout << "Converted Footer part to HTML document" << endl;
	}

	void convertHyperLink(IDocumentPart* pDocPart)
	{
		cout << "Converted HyperLink part to HTML document" << endl;
	}
};