#pragma once

#include "IDocumentPart.h"
#include <iostream>
#include "IDocumentConverter.h"

using namespace std;

class Header : public IDocumentPart
{
public:
	void paint()
	{
		std::cout << "Paint Header"<<endl;
	}
	void convert(IDocumentConverter* pConverter)
	{
		pConverter->convertHeader(this);
	}
};